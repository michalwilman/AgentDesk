<?php
/**
 * Plugin Name: AgentDesk AI Chatbot
 * Plugin URI: https://agentdesk.com/wordpress
 * Description: Add intelligent AI chatbot to your WordPress site. Trained on your content, powered by GPT-4.
 * Version: 1.1.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: AgentDesk
 * Author URI: https://agentdesk.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: agentdesk-chatbot
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('AGENTDESK_VERSION', '1.1.0');
define('AGENTDESK_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AGENTDESK_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AGENTDESK_CDN_URL', 'https://agentdesk-widget-production.up.railway.app/widget.js');
define('AGENTDESK_API_URL', 'https://agentdesk-backend-production.up.railway.app/api');

// Load dependencies with error checking
$required_files = [
    'includes' . DIRECTORY_SEPARATOR . 'class-agentdesk-validator.php',
    'includes' . DIRECTORY_SEPARATOR . 'class-agentdesk-updater.php',
    'includes' . DIRECTORY_SEPARATOR . 'class-agentdesk-heartbeat.php',
    'includes' . DIRECTORY_SEPARATOR . 'class-agentdesk-admin.php',
    'includes' . DIRECTORY_SEPARATOR . 'class-agentdesk-widget.php',
    'includes' . DIRECTORY_SEPARATOR . 'class-agentdesk-api.php',
];

foreach ($required_files as $file) {
    $file_path = AGENTDESK_PLUGIN_DIR . $file;
    // Normalize path separators for cross-platform compatibility
    $file_path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $file_path);
    
    if (file_exists($file_path)) {
        require_once $file_path;
    } else {
        add_action('admin_notices', function() use ($file, $file_path) {
            echo '<div class="error"><p>AgentDesk Error: Missing file - ' . esc_html($file) . '<br>Looking for: ' . esc_html($file_path) . '</p></div>';
        });
        return;
    }
}

/**
 * Initialize plugin
 */
function agentdesk_init() {
    // Load translations
    load_plugin_textdomain('agentdesk-chatbot', false, dirname(plugin_basename(__FILE__)) . '/languages');
    
    // Initialize auto-updater
    if (is_admin()) {
        new AgentDesk_Updater(plugin_basename(__FILE__), AGENTDESK_VERSION);
    }
    
    // Initialize heartbeat (runs on both admin and frontend)
    new AgentDesk_Heartbeat();
    
    // Initialize admin panel
    if (is_admin()) {
        new AgentDesk_Admin();
    }
    
    // Initialize widget on frontend
    if (!is_admin()) {
        new AgentDesk_Widget();
    }
}
add_action('plugins_loaded', 'agentdesk_init');

/**
 * Activation hook
 */
register_activation_hook(__FILE__, 'agentdesk_activate');
function agentdesk_activate() {
    // Set default options
    add_option('agentdesk_api_token', '');
    add_option('agentdesk_position', 'bottom-right');
    add_option('agentdesk_enabled', true);
    add_option('agentdesk_display_pages', 'all'); // all, homepage, posts, pages, custom
    add_option('agentdesk_custom_pages', ''); // comma-separated page IDs
    
    // Create options if they don't exist
    if (get_option('agentdesk_api_token') === false) {
        update_option('agentdesk_api_token', '');
    }
}

/**
 * Deactivation hook
 */
register_deactivation_hook(__FILE__, 'agentdesk_deactivate');
function agentdesk_deactivate() {
    // Clear scheduled heartbeat event
    $timestamp = wp_next_scheduled('agentdesk_heartbeat_event');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'agentdesk_heartbeat_event');
    }
}

/**
 * Uninstall hook
 */
register_uninstall_hook(__FILE__, 'agentdesk_uninstall');
function agentdesk_uninstall() {
    // Remove all plugin options
    delete_option('agentdesk_api_token');
    delete_option('agentdesk_position');
    delete_option('agentdesk_enabled');
    delete_option('agentdesk_display_pages');
    delete_option('agentdesk_custom_pages');
    delete_option('agentdesk_bot_info');
    delete_option('agentdesk_last_heartbeat');
    
    // Clear scheduled events
    $timestamp = wp_next_scheduled('agentdesk_heartbeat_event');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'agentdesk_heartbeat_event');
    }
}

/**
 * Add settings link on plugin page
 */
function agentdesk_add_settings_link($links) {
    $settings_link = '<a href="admin.php?page=agentdesk">' . __('Settings', 'agentdesk-chatbot') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'agentdesk_add_settings_link');

